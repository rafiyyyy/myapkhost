# Ludo

built ludo board game 

- 2 and 4 player mode
- works offline
- no ads
- cross platform

# Blog

[Medium blog](https://harsh-vardhhan.medium.com/i-built-a-120-fps-game-using-flutter-c01ef1d46c1a)

# Components Layout
 
<img width="815" alt="ludo" src="https://github.com/user-attachments/assets/a9cc4093-eef7-4abf-9757-8abf74a1916a">

