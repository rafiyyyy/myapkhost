package com.example.ludo

import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.trakbit.ludozone.BluetoothGattServerModule // Corrected import

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.example.ludo/bluetooth"
    private var gattServerModule: BluetoothGattServerModule? = null

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        gattServerModule = BluetoothGattServerModule(this, methodChannel)

        methodChannel.setMethodCallHandler {
            call, result ->
            when (call.method) {
                "startGattServer" -> {
                    gattServerModule?.startGattServer()
                    result.success(null)
                }
                "stopGattServer" -> {
                    gattServerModule?.stopGattServer()
                    result.success(null)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        gattServerModule?.stopGattServer()
    }
}


