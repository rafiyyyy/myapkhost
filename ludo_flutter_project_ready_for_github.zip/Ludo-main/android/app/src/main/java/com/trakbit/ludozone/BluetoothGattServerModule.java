package com.trakbit.ludozone;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.os.ParcelUuid;
import android.util.Log;

import java.util.UUID;

import io.flutter.plugin.common.MethodChannel;

public class BluetoothGattServerModule {

    private static final String TAG = "LudoGattServer";

    // Your specified UUIDs
    private static final UUID SERVICE_UUID = UUID.fromString("00001801-0000-1000-8000-00805f9b34fb");
    private static final UUID CHARACTERISTIC_UUID = UUID.fromString("00002a01-0000-1000-8000-00805f9b34fb");

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeAdvertiser mBluetoothLeAdvertiser;
    private BluetoothGattServer mGattServer;
    private Context mContext;
    private MethodChannel channel; // To send data back to Flutter

    public BluetoothGattServerModule(Context context, MethodChannel channel) {
        mContext = context;
        this.channel = channel;
        mBluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();
    }

    public void startGattServer() {
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Log.e(TAG, "Bluetooth not available or not enabled");
            // Optionally, send error back to Flutter
            channel.invokeMethod("onBluetoothError", "Bluetooth not available or enabled");
            return;
        }

        mGattServer = mBluetoothManager.openGattServer(mContext, mGattServerCallback);
        if (mGattServer == null) {
            Log.e(TAG, "Unable to create GATT server");
            channel.invokeMethod("onBluetoothError", "Unable to create GATT server");
            return;
        }

        BluetoothGattService service = new BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY);

        BluetoothGattCharacteristic characteristic = new BluetoothGattCharacteristic(
                CHARACTERISTIC_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_WRITE | BluetoothGattCharacteristic.PERMISSION_READ
        );

        service.addCharacteristic(characteristic);
        mGattServer.addService(service);

        startAdvertising();
        Log.i(TAG, "GATT server started and advertising");
        channel.invokeMethod("onGattServerStatus", "started");
    }

    public void stopGattServer() {
        if (mGattServer != null) {
            mGattServer.close();
            mGattServer = null;
        }
        if (mBluetoothLeAdvertiser != null) {
            mBluetoothLeAdvertiser.stopAdvertising(mAdvertiseCallback);
            mBluetoothLeAdvertiser = null;
        }
        Log.i(TAG, "GATT server stopped");
        channel.invokeMethod("onGattServerStatus", "stopped");
    }

    private void startAdvertising() {
        mBluetoothLeAdvertiser = mBluetoothAdapter.getBluetoothLeAdvertiser();
        if (mBluetoothLeAdvertiser == null) {
            Log.e(TAG, "Failed to get BLE advertiser");
            channel.invokeMethod("onBluetoothError", "Failed to get BLE advertiser");
            return;
        }

        AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(true)
                .build();

        AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName(true)
                .addServiceUuid(new ParcelUuid(SERVICE_UUID))
                .build();

        mBluetoothLeAdvertiser.startAdvertising(settings, data, mAdvertiseCallback);
    }

    private final AdvertiseCallback mAdvertiseCallback = new AdvertiseCallback() {
        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.i(TAG, "BLE Advertising started successfully");
        }

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e(TAG, "BLE Advertising onStartFailure: " + errorCode);
            channel.invokeMethod("onBluetoothError", "Advertising failed: " + errorCode);
        }
    };

    private final BluetoothGattServerCallback mGattServerCallback = new BluetoothGattServerCallback() {
        @Override
        public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
            super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value);

            if (CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                if (value != null && value.length > 0) {
                    int diceValue = value[0];
                    Log.d(TAG, "Received dice value: " + diceValue + " from " + device.getAddress());
                    // Send dice value to Flutter via MethodChannel
                    channel.invokeMethod("onDiceValueReceived", diceValue);
                }
                if (responseNeeded) {
                    mGattServer.sendResponse(device, requestId, android.bluetooth.BluetoothGATT.GATT_SUCCESS, offset, value);
                }
            } else {
                if (responseNeeded) {
                    mGattServer.sendResponse(device, requestId, android.bluetooth.BluetoothGatt.GATT_FAILURE, offset, null);
                }
            }
        }

        // Other GATT server callbacks can be implemented here
    };
}


