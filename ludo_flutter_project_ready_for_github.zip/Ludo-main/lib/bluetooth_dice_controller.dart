import 'package:flutter/services.dart';

class BluetoothDiceController {
  static const MethodChannel _channel = MethodChannel('com.example.ludo/bluetooth');

  // A callback function to be set by the game logic to receive dice values
  Function(int)? onDiceValueReceivedCallback;

  BluetoothDiceController() {
    _channel.setMethodCallHandler(_handleMethodCall);
  }

  Future<void> startGattServer() async {
    try {
      await _channel.invokeMethod('startGattServer');
      print('Bluetooth GATT Server started.');
    } on PlatformException catch (e) {
      print("Failed to start GATT server: '${e.message}'.");
    }
  }

  Future<void> stopGattServer() async {
    try {
      await _channel.invokeMethod('stopGattServer');
      print('Bluetooth GATT Server stopped.');
    } on PlatformException catch (e) {
      print("Failed to stop GATT server: '${e.message}'.");
    }
  }

  Future<dynamic> _handleMethodCall(MethodCall call) async {
    switch (call.method) {
      case 'onDiceValueReceived':
        final int diceValue = call.arguments as int;
        print('Received dice value from Bluetooth: $diceValue');
        if (onDiceValueReceivedCallback != null) {
          onDiceValueReceivedCallback!(diceValue);
        }
        break;
      case 'onGattServerStatus':
        print('GATT Server Status: ${call.arguments}');
        break;
      case 'onBluetoothError':
        print('Bluetooth Error: ${call.arguments}');
        break;
      default:
        print('Unknown method ${call.method}');
    }
  }
}


